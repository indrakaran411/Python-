ragrank.prompt.base
===================

.. automodule:: ragrank.prompt.base
    :members:
