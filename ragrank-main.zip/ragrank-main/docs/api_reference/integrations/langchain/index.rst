ragrank.integrations.langchain
===============================

.. autosummary::
    ragrank.integrations.langchain.langchain_llm_wrapper

.. automodule:: ragrank.integrations.langchain
    :members:

.. toctree::
    :maxdepth: 1

    langchain_llm_wrapper