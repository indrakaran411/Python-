ragrank.dataset
===============

.. autosummary::
    ragrank.dataset.base
    ragrank.dataset.reader

.. automodule:: ragrank.dataset
    :members:

.. toctree::
   :maxdepth: 1

   base
   reader