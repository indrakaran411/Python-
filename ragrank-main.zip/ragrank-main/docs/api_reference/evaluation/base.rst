ragrank.evaluation.base
=======================

.. automodule:: ragrank.evaluation.base
    :members: