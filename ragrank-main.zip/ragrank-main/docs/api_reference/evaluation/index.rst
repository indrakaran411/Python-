ragrank.evaluation
==================

.. autosummary::
    ragrank.evaluation.base
    ragrank.evaluation.outputs

.. automodule:: ragrank.evaluation
    :members:

.. toctree::
    :maxdepth: 1

    base
    outputs