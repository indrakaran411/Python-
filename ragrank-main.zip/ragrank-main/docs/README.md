This folder contain the documentation as well as the API reference files

- [documentation](./docs/)
- [API reference](./api_reference/)