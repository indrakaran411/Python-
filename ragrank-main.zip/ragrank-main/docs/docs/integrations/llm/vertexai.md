# Vertex AI

```{attention}
This feature is not implemented yet ! Will update this shortly 😊
```