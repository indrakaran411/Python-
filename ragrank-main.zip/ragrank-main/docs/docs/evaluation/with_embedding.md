(with-custom-embedding)=
# With Embeddings

```{Attention}
Customization of embeddings for internal use is currently unavailable. Please proceed with the default embedding options. Thank you for your understanding.
```