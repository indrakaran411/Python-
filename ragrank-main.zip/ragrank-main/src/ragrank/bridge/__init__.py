"""bridge for external modules"""
