""" "The prompt module for ragrank"""

from ragrank.prompt.base import Prompt

__all__ = ["Prompt"]
