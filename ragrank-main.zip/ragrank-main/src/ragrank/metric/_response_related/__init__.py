"""Base class for the response related metric"""
