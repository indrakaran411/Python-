"""Base class for the context related metric"""
