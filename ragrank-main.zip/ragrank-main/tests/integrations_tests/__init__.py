"""Test cases for the integrations module"""
