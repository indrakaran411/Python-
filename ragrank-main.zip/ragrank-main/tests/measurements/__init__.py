"""Measurement taking module for testing"""
